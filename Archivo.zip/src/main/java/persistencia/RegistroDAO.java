/*
import java.sql.ResultSet;
iimport java.sql.SQLException;
import java.util.ArrayList;
import logica.Login;


package persistencia;

 */